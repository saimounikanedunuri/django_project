from django.views.generic.base import TemplateView
from django.shortcuts import render


class HomeView(TemplateView):

    template_name = 'index.html'

def index(request):
 	return render(request,'index.html')
def aboutus(request):
    return render(request,'aboutus.html')
def contactus(request):
	return render(request,'contactus.html')
def department(request):
	return render(request,'department.html')
def sports(request):
	return render(request,'sports.html')